const dotenv = require("dotenv");
dotenv.config();
const mysql = require("mysql2");
const { createClient } = require("@supabase/supabase-js");

//로컬
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});
module.exports = pool.promise();

//운영
// const supabaseUrl = "https://dljhxnsvhwecnsdtvqeq.supabase.co"; // 본인의 프로젝트 URL
// const supabaseKey =
//   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRsamh4bnN2aHdlY25zZHR2cWVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAzODg2ODksImV4cCI6MjA2NTk2NDY4OX0.B31tJnK-zHBXDHW_YiAr2nvDkqmfV_bdcLNJkUcQltE"; // 본인의 anon key

// const supabase = createClient(supabaseUrl, supabaseKey);

// module.exports = supabase;
